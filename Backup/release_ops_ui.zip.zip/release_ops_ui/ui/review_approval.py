# ui/review_approval.py

import streamlit as st
from pathlib import Path
from datetime import datetime, UTC

from models.release_context import ReleaseContext
from services.approval_service import create_approval_record
from utils.hashing import calculate_file_hash
from services.git_service import get_remote_branch_head


def render_review_approval(context: ReleaseContext) -> None:
    """
    Review & Approval UI with shareable review link support.
    """

    st.header("🧐 Review & Approval")

    # -------------------------------------------------
    # Load context from URL (review link)
    # -------------------------------------------------
    query_params = st.query_params

    link_shared_path = query_params.get("shared_path", "")
    link_search_tag = query_params.get("tag", "")
    requested_by = query_params.get("requested_by", "")

    opened_via_link = bool(link_shared_path and link_search_tag)

    # -------------------------------------------------
    # Banner for link-based review
    # -------------------------------------------------
    if opened_via_link:
        st.info(
            f"🧭 **This review was requested by:** `{requested_by or 'Release Engineer'}`\n\n"
            "The review context is locked to ensure audit safety."
        )

    # -------------------------------------------------
    # Shared path & search tag inputs
    # -------------------------------------------------
    shared_root = st.text_input(
        "Shared review path (contains dev / cit / retro folders)",
        value=link_shared_path,
        disabled=opened_via_link,
        placeholder="\\\\shared\\release_reviews\\BANKING-XXXXXX"
    )

    search_tag = st.text_input(
        "Search tag for review context",
        value=link_search_tag,
        disabled=opened_via_link,
        placeholder="--BANKING-123456 changes"
    )

    # -------------------------------------------------
    # Generate review link (requester only)
    # -------------------------------------------------
    if shared_root and search_tag and not opened_via_link:
        review_link = (
            f"http://localhost:8501/"
            f"?shared_path={shared_root}"
            f"&tag={search_tag}"
            f"&requested_by={context.release_jira or 'Release Engineer'}"
        )

        st.markdown("### 🔗 Review Link for Manager")
        st.code(review_link, language="text")
        st.info("Copy this link and share it with your manager for review.")

    # -------------------------------------------------
    # Validate shared path
    # -------------------------------------------------
    if not shared_root or not search_tag:
        st.warning("Provide shared path and search tag to continue.")
        return

    shared_root_path = Path(shared_root)
    retro_path = shared_root_path / "retro"

    if not retro_path.exists():
        st.error("❌ Retro folder not found in shared path.")
        return

    # -------------------------------------------------
    # List files for review
    # -------------------------------------------------
    st.markdown("### 📂 Files for Review")

    approved_files = {}

    files = list(retro_path.rglob("*"))

    if not files:
        st.warning("No files found in retro folder.")
        return

    for file in files:
        if file.is_file():
            rel_path = file.relative_to(retro_path)
            file_hash = calculate_file_hash(file)
            approved_files[str(rel_path)] = file_hash
            st.write(f"📄 {rel_path}")

    st.divider()

    # -------------------------------------------------
    # Approval section
    # -------------------------------------------------
    approve_checked = st.checkbox(
        "✅ I have reviewed and approve these changes"
    )

    if approve_checked:
        approval_id = st.text_input(
            "Approval ID / Manager Reference",
            placeholder="APPROVAL-001"
        )

        if st.button("📝 Record Approval"):
            if not approval_id:
                st.error("Approval ID is required.")
                return

            # Lock context
            context.shared_root_path = shared_root_path
            context.shared_retro_path = retro_path
            context.search_tag = search_tag
            context.approval_id = approval_id
            context.approved_files = approved_files
            context.approved_at = datetime.now(UTC).isoformat()

            # Capture base commit for drift detection
            base_commit = get_remote_branch_head(
                context.repo_path,
                context.base_branch
            )
            context.base_commit = base_commit

            approval_file = create_approval_record(
                approval_dir=Path("data/approvals"),
                approval_id=approval_id,
                environment=context.environment,
                release_type=context.release_type,
                base_branch=context.base_branch,
                base_commit=base_commit,
                approved_files=approved_files
            )

            context.approval_file = approval_file

            st.success("✅ Approval recorded successfully.")
            st.rerun()

    # -------------------------------------------------
    # Already approved
    # -------------------------------------------------
    if context.approval_id:
        st.success(f"🔒 Approved (Approval ID: {context.approval_id})")
