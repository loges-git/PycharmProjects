# ui/release_flow.py

import streamlit as st

from models.release_context import ReleaseContext
from services.release_service import execute_release
from validators.drift_validator import (
    validate_no_drift,

)
from validators.drift_validator import DriftDetectedError, DriftReadError


def render_release_summary(context):
    st.header("📦 Release Summary")

    st.markdown("### 🔐 Release Details")

    st.write(f"**Environment:** {context.environment.name}")
    st.write(f"**Release Type:** {context.release_type.name}")
    st.write(f"**Cluster:** {context.cluster}")
    st.write(f"**Base Branch:** `{context.base_branch}`")
    st.write(f"**Release Branch:** `{context.release_branch}`")
    st.write(f"**Release Jira:** `{context.release_jira}`")

    st.divider()

    st.markdown("### 📂 Approved Files")

    if not context.approved_files:
        st.warning("No approved files found.")
        return

    for file_path in context.approved_files.keys():
        st.write(f"📄 `{file_path}`")


def render_release_flow(context: ReleaseContext) -> None:
    """
    Final release execution UI.
    """

    st.header("🚀 Release Execution")

    # -------------------------
    # Pre-flight checks
    # -------------------------
    missing = []

    if not context.environment:
        missing.append("Environment")
    if not context.release_type:
        missing.append("Release Type")
    if not context.repo_path:
        missing.append("Repository")
    if not context.base_branch:
        missing.append("Base Branch")
    if not context.release_branch:
        missing.append("Release Branch")
    if not context.release_jira:
        missing.append("Release Jira")
    if not context.approval_file:
        missing.append("Approval")

    if missing:
        st.warning(
            "Cannot proceed. Missing prerequisites:\n- "
            + "\n- ".join(missing)
        )
        return

    # -------------------------
    # Summary
    # -------------------------
    st.markdown("### 📋 Release Summary")

    st.code(f"""
Environment    : {context.environment.value}
Release Type   : {context.release_type.value}
Cluster        : {context.cluster}
Base Branch    : {context.base_branch}
Release Branch : {context.release_branch}
Release Jira   : {context.release_jira}
Approval ID    : {context.approval_id}
""")

    # -------------------------
    # Final confirmation
    # -------------------------
    confirm = st.checkbox(
        "⚠️ I confirm that I want to execute this release"
    )

    if not confirm:
        st.info("Awaiting final confirmation.")
        return

    # --------------------------------------------------
    # Final confirmation gate
    # --------------------------------------------------
    confirm = st.checkbox(
        "I confirm that the above details are correct and approved"
    )

    st.markdown("### 🛡 Approval Status")

    if not context.approval_file:
        st.warning("⏳ No approval recorded yet.")
        return

    try:
        validate_no_drift(
            repo_path=context.repo_path,
            base_branch=context.base_branch,
            approval_file=context.approval_file
        )

        st.success("✅ APPROVED — No drift detected since approval")

    except DriftDetectedError as e:
        st.error("⚠️ DRIFTED — Code has changed since approval")

        st.table(
            [{"File": f, "Status": "❌ Drifted"} for f in e.drifted_files]
        )

        st.stop()

    except DriftReadError as e:
        st.error("❌ Unable to validate drift due to repository read error")
        st.code(str(e))
        st.stop()

    if st.button("🚀 Execute Release", disabled=not confirm):
        try:
            execute_release(context)
            st.success("🎉 Release executed successfully!")
        except Exception as e:
            if st.session_state.get("debug"):
                st.exception(e)
            else:
                st.error(
                    "Release failed. Enable Debug Mode for details."
                )
