# services/release_service.py

from pathlib import Path

from models.release_context import ReleaseContext
from validators.drift_validator import validate_no_drift, DriftDetectedError
from validators.repo_validator import ensure_clean_working_tree

from services.git_service import (
    checkout_branch,
    create_or_checkout_branch,
    stage_all,
    commit_changes,
    push_branch
)


def execute_release(context: ReleaseContext) -> None:
    """
    Execute CIT / BFX release.
    HARD BLOCK if drift is detected.
    """

    # ======================================================
    # 🔒 SAFETY GATE 1: Working tree must be clean
    # ======================================================
    ensure_clean_working_tree(context.repo_path)

    # ======================================================
    # 🔒 SAFETY GATE 2: Drift validation (CRITICAL)
    # ======================================================
    try:
        validate_no_drift(
            repo_path=context.repo_path,
            base_branch=context.base_branch,
            approval_file=context.approval_file
        )
    except DriftDetectedError as e:
        raise RuntimeError(
            "❌ RELEASE BLOCKED: Approved files have drifted from base branch.\n\n"
            f"{e}"
        )

    # ======================================================
    # 🧭 Git flow
    # ======================================================
    # Checkout base branch
    checkout_branch(context.repo_path, context.base_branch)

    # Create or checkout release branch
    create_or_checkout_branch(
        repo_path=context.repo_path,
        branch_name=context.release_branch,
        base_branch=context.base_branch
    )

    # ======================================================
    # 📂 Apply approved files
    # ======================================================
    for rel_path in context.approved_files.keys():
        src = context.shared_retro_path / rel_path
        dst = context.repo_path / rel_path

        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    # -----------------------------
    # Commit message enforcement
    # -----------------------------
    if not context.release_jira:
        raise RuntimeError(
            "❌ Release Jira is missing. Cannot commit without BANKING Jira."
        )

    # ======================================================
    # 📦 Commit & push
    # ======================================================
    stage_all(context.repo_path)

    commit_changes(
        context.repo_path,
        message=context.release_jira
    )

    push_branch(
        context.repo_path,
        context.release_branch
    )
