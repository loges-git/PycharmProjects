# services/approval_service.py

import json
from pathlib import Path
from typing import Dict

from models.release_context import Environment, ReleaseType


class ApprovalServiceError(Exception):
    """Raised when approval service fails."""


def create_approval_record(
    approval_dir: Path,
    approval_id: str,
    environment: Environment,
    release_type: ReleaseType,
    base_branch: str,
    base_commit: str,
    approved_files: Dict[str, str]
) -> Path:
    """
    Persist approval record to disk.
    """

    approval_dir.mkdir(parents=True, exist_ok=True)

    approval_file = approval_dir / f"{approval_id}.json"

    record = {
        "approval_id": approval_id,
        "environment": environment.value,
        "release_type": release_type.value,
        "base_branch": base_branch,
        "base_commit": base_commit,
        "approved_files": approved_files
    }

    with approval_file.open("w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)

    return approval_file


def load_approval_record(
    approval_file: Path
) -> dict:
    """
    Load approval record from disk.
    """

    if not approval_file.exists():
        raise ApprovalServiceError(
            f"Approval record not found: {approval_file}"
        )

    with approval_file.open("r", encoding="utf-8") as f:
        return json.load(f)
